module.exports.function = function makeDetailFromTimeOrderedSchedule (timeOrderedSchedule) {
  return {}
}
