module.exports.function = function filterMovieWithTime (movieSchedule, dateTimeExpression, isStartTime) {
  let result = [];
  let input = movieSchedule;

  if(isStartTime){
  //   input.forEach(function(el){
  //     if(!el.theater.theaterName.includes(theaterName)){
  //       result.push(el);
  //     }
  //   })
  // } else {
  //   input.forEach(function(el){
  //     if(el.theater.theaterName.includes(theaterName)){
  //       result.push(el);
  //     }
  //   })
  }
  return result
  
  return {}
}
