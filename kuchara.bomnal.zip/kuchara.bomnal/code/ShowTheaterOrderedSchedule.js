const data = require('./sample/newStructure.js');

module.exports.function = function showTheaterOrderedSchedule (theaterOrderedSchedule) {
  // iconUri = '/images/brand/' + brandName
  return data;
}
